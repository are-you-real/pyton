#include <iostream>
#include <math.h>
#include <cmath>
#include <fstream>

#define E -0.6

using namespace std;

double f(double x){
	return -exp(-x*x)-1.2*exp(-(x-2.0)*(x-2.0))-E;
}

double f_p(double x){
	return 2.0*x*exp(-x*x)-1.2*(-2.0*x+4.0)*exp(-(x-2.0)*(x-2.0));
}

int main(){
	
	fstream plik;
	plik.open("newton.txt", ios::out | ios::app);
	
	//METODA BISEKCJI
	/*double a,b,m;
	b=0.0;
	a=-1.0;
	int i=1;
	
	while(abs(a-b)>0.000001){
	m=(a+b)/2.0;
	if( (f(a)*f(m))<0 ) b=m;	
	if( (f(b)*f(m)<0) ) a=m;
	plik<<i<<" "<<abs(f(m))<<endl;
	i++;
	}
	cout<<m<<endl;*/
	
	//METODA NEWTONA
	double x0,xn;
	int i=1;
	x0=2.5;
	xn=x0-(f(x0)/f_p(x0));
	cout<<xn<<endl;
	
	while(abs(f(xn))>0.000001){
	plik<<i<<" "<<abs(f(xn))<<endl;
	xn=xn-(f(xn)/f_p(xn));
	cout<<xn<<" "<<abs(f(xn))<<endl;
	i++;
	}

	
return 0;
}
