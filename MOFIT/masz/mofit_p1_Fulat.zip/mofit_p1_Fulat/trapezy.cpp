#include <iostream>
#include <math.h>
#include <cmath>
#include <fstream>
#include <vector>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <cstdio>

#define m 1.0

using namespace std;

double alfa;

double V(double x){
	return -exp(-x*x)-1.2*exp(-(x-2.0)*(x-2.0));
}

double V_p(double x){
	return 2.0*x*exp(-x*x)-1.2*(-2.0*x+4.0)*exp(-(x-2.0)*(x-2.0));
}

double V_pp(double x){
	return exp(-(x-2)*(x-2))*(-4.8*x*x+19.2*x-16.8)+exp(-x*x)*(2-4*x*x);
}

double F1(double xn1, double xn, double vn1, double vn, double dt){
	return xn1-xn-dt/2.0*vn1-dt/2.0*vn;
}

double F2(double xn1, double xn, double vn1, double vn, double dt){
	return vn1-vn-dt/2.0*(-1/m*V_p(xn1)-alfa*vn1)-dt/2.0*(-1/m*V_p(xn)-alfa*vn);
}

void schemat_trapezow (double x0, double v0, double T, double dt, fstream &plik){

	double t=0.0;
	int i=1;
	int mi=0;
	double epsilon=1e-6;

	vector <double> x;
	vector <double> v;

	x.push_back(x0);
	v.push_back(v0);

	double a[4];
	a[0]=1.0;
	a[1]=-dt/2.0;
	a[2]=0.0;
	a[3]=1+dt/2.0*alfa;

	double b[2];
	b[0]=0.0;
	b[1]=0.0;

	while (t<=T){
			x.push_back(x[i-1]);
			v.push_back(v[i-1]);
			mi=0;
			while(abs(F1(x[i],x[i-1],v[i],v[i-1],dt))>epsilon || abs(F2(x[i],x[i-1],v[i],v[i-1],dt))>epsilon){
				a[2]=dt/(2.0*m)*V_pp(x[i]);
				b[0]=-F1(x[i],x[i-1],v[i],v[i-1],dt);
				b[1]=-F2(x[i],x[i-1],v[i],v[i-1],dt);
				gsl_matrix_view A = gsl_matrix_view_array (a, 2, 2);
				gsl_vector_view  X = gsl_vector_view_array (b, 2);
				gsl_vector *bb = gsl_vector_alloc (2);
				int s;
				gsl_permutation * p = gsl_permutation_alloc (2);
				gsl_linalg_LU_decomp (&A.matrix, p, &s);
				gsl_linalg_LU_solve (&A.matrix, p, &X.vector, bb);
				x[i]=x[i]+gsl_vector_get(bb,0);
				v[i]=v[i]+gsl_vector_get(bb,1);
				gsl_permutation_free (p);
				gsl_vector_free (bb);
				mi+=1;
			}
			plik<<i<<" "<<t<<" "<<x[i]<<" "<<v[i]<<" "<<m*v[i]*v[i]/2.0<<" "<<V(x[i])<<" "<<m*v[i]*v[i]/2.0+V(x[i])<<endl;
			i+=1;
			t+=dt;
			cout<<t<<endl;
	}

}

int main(int argc, char* argv[]){

	fstream plik;
	plik.open(argv[1], ios::out);
	plik.precision(14);


	double T=atof(argv[2]);
	double dt=atof(argv[3]);
	double x0=2.83288;
	double v0=0.0;
	alfa=atof(argv[4]);

	vector <double> x;
	vector <double> v;

	schemat_trapezow(x0,v0,T,dt,plik);

	plik.close();

	return 0;
}
