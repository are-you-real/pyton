#include <iostream>
#include <math.h>
#include <cmath>
#include <fstream>
#include <vector>

#define m 1.0

using namespace std;

double V(double x){
	return -exp(-x*x)-1.2*exp(-(x-2.0)*(x-2.0));
}

double V_p(double x){
	return 2.0*x*exp(-x*x)-1.2*(-2.0*x+4.0)*exp(-(x-2.0)*(x-2.0));
}

void opory_ruchu (vector <double> x, vector <double> v, vector <double> Ek, double (*V)(double), double (*V_p)(double), double T, double dt, double alfa, fstream & plik){

	double t=0.0;
	int i=0;

	while (t<=T){

		x.push_back(x[i]+v[i]*dt);
		v.push_back(v[i]-1/m*V_p(x[i])*dt-alfa*v[i]*dt);
		Ek.push_back(m*v[i+1]*v[i+1]/2.0);
		plik<<t<<" "<<x[i]<<" "<<v[i]<<" "<<Ek[i]<<" "<<V(x[i])<<" "<<Ek[i]+V(x[i])<<endl;

		t+=dt;
		i+=1;

	}
	plik<<t<<" "<<x[i]<<" "<<v[i]<<" "<<Ek[i]<<" "<<V(x[i])<<" "<<Ek[i]+V(x[i])<<endl;
}

int main(){

	fstream plik;
	plik.open("euler_100_0001.txt", ios::out);

	double T=100.0;
	double dt=0.001;
	double x0=2.83288;
	double v0=0.0;
	double alfa=0.0;

	vector <double> x;
	vector <double> v;
	vector <double> Ek;

	x.push_back(x0);
	v.push_back(v0);
	Ek.push_back(m*v0*v0/2.0);

	opory_ruchu(x,v,Ek,&V,&V_p,T,dt,alfa,plik);

	plik.close();

	return 0;
}
