#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

#define a 201
#define b 51
#define dx 1
#define dy 1
#define u0 1.0

using namespace std;

void strumien(double ** psi){
	for(int i=0; i<b; i+=dy){
		for(int j=0; j<a; j+=dx){
			psi[i][j]=0.0;
		}
	}
	//lewy brzeg
	for(int i=0; i<b; i+=dy){
		psi[i][0]=u0*i*dy+50;
	}
	//prawy brzeg
	for(int i=0; i<b; i+=dy){
		psi[i][a-1]=u0*i*dy+50;
	}
	//gorny brzeg
	for(int j=0; j<a; j+=dx){
		psi[b-1][j]=u0*(b-1)*dy+50;
	}
	for(int i=0; i<=20; i+=dy){
		psi[i][95]=psi[0][0];
	}
	for(int i=0; i<=20; i+=dy){
		psi[i][105]=psi[0][0];
	}
	for(int j=0; j<95; j+=dx){
		psi[0][j]=psi[0][0];
	}
	for(int j=106; j<a-1; j+=dx){
		psi[0][j]=psi[0][0];
	}
	for(int j=95; j<=105; j+=dx){
		psi[20][j]=psi[0][0];
	}
}

int main(){

double eps=0.00001;
double a_sum, ap_sum;
double psi_x, psi_y;

fstream plik;
plik.open("przeplyw_str.txt", ios::out);
plik.precision(11);

double **psi=new double *[b];
for(int i=0; i<b; i++) psi[i]=new double [a];

double **psin=new double *[b];
for(int i=0; i<b; i++) psin[i]=new double [a];

strumien(psi);
strumien(psin);

int iter=0;
//GLOWNA PETLA
do{
  ap_sum=a_sum;
  a_sum=0.0;
  for(int i=1; i<b-1; i+=dy){
  	for(int j=1; j<a-1; j+=dx){
			if ((i>=1 && i<=20)&&(j>=95 && j<=105)) continue;
  		else psin[i][j]=0.25*(psi[i+1][j]+psi[i-1][j]+psi[i][j+1]+psi[i][j-1]);
  	}
  }
	for(int i=1; i<b-1; i+=dy){
		for(int j=1; j<a-1; j+=dx){
			psi[i][j]=psin[i][j];
		}
	}
  for(int i=1; i<b-1; i+=dy){
  	for(int j=1; j<a-1; j+=dx){
      psi_x=(psi[i+dx][j]-psi[i][j])/dx;
      psi_y=(psi[i][j+dy]-psi[i][j])/dy;
      a_sum+=1/2.0*(psi_x*psi_x+psi_y*psi_y);
  	}
  }
  iter++;
	cout<<iter<<" "<<a_sum-ap_sum<<" "<<endl;
}while(abs(a_sum-ap_sum)>eps);

//ZAPIS DO PLIKU
for(int i=0; i<b; i+=dy){
	for(int j=0; j<a; j+=dx){
		plik<<j<<" "<<i<<" "<<psi[i][j]<<" "<<endl;
	}
	plik<<endl;
}

return 0;
}
