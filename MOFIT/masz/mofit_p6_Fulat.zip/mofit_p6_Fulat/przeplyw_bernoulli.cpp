#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

#define a 201
#define b 51
#define dx 1
#define dy 1
#define u0 1.0
#define p0 10.0
#define ro 1.0

using namespace std;

void brzegowe(double ** tab){
	//lewy brzeg
	for(int j=0; j<b; j+=dy){
		tab[j][0]=u0;
	}
	//prawy brzeg
	for(int j=0; j<b; j+=dy){
		tab[j][a-1]=u0*200;
	}
	//gorny brzeg
	for(int i=0; i<a; i+=dx){
		tab[b-1][i]=u0*i;
	}
	//lewa przeszkoda
	for(int j=0; j<=20; j+=dy){
		tab[j][95]=tab[j][94];
	}
	//prawa przeszkoda
	for(int j=0; j<=20; j+=dy){
		tab[j][105]=tab[j][106];
	}
	//gorna przeszkoda
	for(int i=95; i<=105; i+=dx){
		tab[20][i]=tab[21][i];
	}
	//rogi przeszkody
	tab[20][95]=0.5*(tab[20][94]+tab[20][95]);
	tab[20][105]=0.5*(tab[20][106]+tab[21][105]);
	//lewy dol
	for(int i=0; i<95; i+=dx){
		tab[0][i]=tab[1][i];
	}
	//prawy dol
	for(int i=106; i<a-1; i+=dx){
		tab[0][i]=tab[1][i];
	}
}

void poczatkowe(double **tab){
	for(int j=1; j<b-1; j+=dy){
		for(int i=1; i<a-1; i+=dx){
			if ((j>0 && j<20)&&(i>95 && i<105)) tab[j][i]=0.0;
			else tab[j][i]=u0*i;
		}
	}
}

int main(){

double eps=0.00001;
double a_sum, ap_sum;
double pot_x, pot_y;
double u,v;

fstream plik;
plik.open("przeplyw_bernoulli.txt", ios::out);
plik.precision(11);

double **pot=new double *[b];
for(int j=0; j<b; j++) pot[j]=new double [a];

double **potn=new double *[b];
for(int j=0; j<b; j++) potn[j]=new double [a];

double **p=new double *[b];
for(int j=0; j<b; j++) p[j]=new double [a];

poczatkowe(pot);
poczatkowe(potn);
brzegowe(pot);
brzegowe(potn);

int iter=0;
do{
  ap_sum=a_sum;
  a_sum=0.0;

	/*for(int i=0; i<=94; i+=dx) pot[0][i]=pot[1][i];
	for(int i=106; i<=a; i+=dx) pot[0][i]=pot[1][i];

	for(int i=0; i<=94; i+=dx) potn[0][i]=potn[1][i];
	for(int i=106; i<=a; i+=dx) potn[0][i]=potn[1][i];*/
	brzegowe(pot);
	brzegowe(potn);

  for(int j=1; j<b-1; j+=dy){
  	for(int i=1; i<a-1; i+=dx){
			if ((j>0 && j<20)&&(i>95 && i<105)) continue;
  		else potn[j][i]=0.25*(pot[j][i-1]+pot[j-1][i]+pot[j][i+1]+pot[j+1][i]);
  	}
  }
	for(int j=1; j<b-1; j+=dy){
		for(int i=1; i<a-1; i+=dx){
			if ((j>0 && j<20)&&(i>95 && i<105)) continue;
			else pot[j][i]=potn[j][i];
		}
	}
  for(int j=1; j<b-1; j+=dy){
  	for(int i=1; i<a-1; i+=dx){
			if ((j>=0 && j<=20)&&(i>=95 && i<=105)) continue;
			else {
				pot_x=(pot[j][i+dx]-pot[j][i])/dx;
			  pot_y=(pot[j+dy][i]-pot[j][i])/dy;
			  a_sum+=1/2.0*(pot_x*pot_x+pot_y*pot_y);
			}
  	}
  }
  iter++;
	cout<<iter<<" "<<a_sum-ap_sum<<" "<<endl;
}while(abs(a_sum-ap_sum)>eps);
//while(abs(a_sum-ap_sum)>eps);
brzegowe(pot);

for(int j=0; j<b; j+=dy){
	for(int i=0; i<a; i+=dx) p[j][i]=0.0;
}

for(int j=0; j<b-1; j+=dy){
	for(int i=0; i<a-1; i+=dx){
		if ((j>=0 && j<=20)&&(i>=95 && i<=105)) continue;
		else {
				u=(pot[j][i+dx]-pot[j][i])/dx;
				v=(pot[j+dy][i]-pot[j][i])/dy;
				p[j][i]=p0+ro*u0*u0-ro*(u*u+v*v);
		}
	}
}

for(int j=0; j<b; j+=dy){
	for(int i=0; i<a; i+=dx) plik<<i<<" "<<j<<" "<<p[j][i]<<endl;
	plik<<endl;
}

return 0;
}
