#include <iostream>
#include <cmath>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>

#define J 100.0
#define H 0.1

using namespace std;

int main(){

int N=101;
int dx=1;
int dy=1;
double w;
double a=0.0;
double ap=0.0;
double eps=0.00001;
double pot_x,pot_y,pot_xx,pot_yy;

fstream plik;
plik.open("poissong_wynik.txt", ios::out);
plik.precision(11);

double **gest=new double *[N];
for(int i=0; i<N; i++) gest[i]=new double [N];

for(int i=0; i<N; i++){
	for(int j=0; j<N; j++){
    if((i>=40 && i<=60)&&(j>=40 && j<=60)) gest[i][j]=1.0;
    else gest[i][j]=0.0;
	}
}

double **pot=new double *[N];
for(int i=0; i<N; i++) pot[i]=new double [N];

for(int i=0; i<N; i++){
	for(int j=0; j<N; j++){
		pot[i][j]=0.0;
	}
}

double **pot_p=new double *[N];
for(int i=0; i<N; i++) pot_p[i]=new double [N];

for(int i=0; i<N; i++){
	for(int j=0; j<N; j++){
		pot_p[i][j]=0.0;
	}
}

//GLOWNA PETLA DO ZBIEŻNOŚCI
for(w=1.0; w<1.1; w+=1){
	cout<<w<<endl;
	for(int i=0; i<N; i++){
		for(int j=0; j<N; j++){
	    if((i>=40 && i<=60)&&(j>=40 && j<=60)) gest[i][j]=1.0;
	    else gest[i][j]=0.0;
		}
	}
	for(int i=0; i<N; i++){
		for(int j=0; j<N; j++){
			pot[i][j]=0.0;
		}
	}
	for(int i=0; i<N; i++){
		for(int j=0; j<N; j++){
			pot_p[i][j]=0.0;
		}
	}
	int iter=0;
	do{
	  ap=a;
	  a=0.0;
	  for(int i=1; i<N-1; i++){
	  	for(int j=1; j<N-1; j++){
	  		pot_p[i][j]=(1.0-w)*pot[i][j]+w/4.0*(pot[i+1][j]+pot[i-1][j]+pot[i][j+1]+pot[i][j-1]+gest[i][j]*dx*dx);
	  	}
	  }
		for(int i=0; i<N; i++){
			for(int j=0; j<N; j++){
				pot[i][j]=pot_p[i][j];
			}
		}
	  for(int i=1; i<N-1; i++){
	  	for(int j=1; j<N-1; j++){
	      pot_x=(pot[i+dx][j]-pot[i][j])/dx;
	      pot_y=(pot[i][j+dy]-pot[i][j])/dy;
	      a+=1/2*(pot_x*pot_x+pot_y*pot_y)-gest[i][j]*pot[i][j];
	  	}
	  }
	  //cout<<w<<" "<<a<<endl;
	  iter++;
		cout<<w<<" "<<a<<endl;
	}while(abs(a-ap)>eps);
//	plik<<w<<" "<<iter<<endl;
}
for(int i=0; i<N; i++){
	for(int j=0; j<N; j++){
		plik<<i<<" "<<j<<" "<<pot[i][j]<<endl;
	}
	plik<<endl;
}
return 0;
}
